package com.example.soc_lms.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.soc_lms.entity.Author;
import com.example.soc_lms.entity.Book;
import com.example.soc_lms.entity.Category;
import com.example.soc_lms.entity.Publisher;
import com.example.soc_lms.service.AuthorService;
import com.example.soc_lms.service.BookService;
import com.example.soc_lms.service.CategoryService;
import com.example.soc_lms.service.PublisherService;

@RestController
@RequestMapping("/api/books")
public class BookController {

	@Autowired
	private BookService bookService;
	@Autowired
	private AuthorService authorService;
	@Autowired
	private CategoryService categoryService;
	@Autowired
	private PublisherService publisherService;
	
	@GetMapping
	public ResponseEntity<List<Book>> getAllBooks(){
		
		List<Book> books = bookService.getAllBooks();
		return ResponseEntity.ok(books);
		
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Book> getBook(@PathVariable int id){
		Book book = bookService.getBookById(id);
		if(book == null) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok(book);
	}
	@PutMapping("/{id}")
	public ResponseEntity<Book> updateBook(@PathVariable int id, @RequestBody Book book){
		Book existingBook = bookService.getBookById(id);
		if(existingBook == null) {
			return ResponseEntity.notFound().build();
		}
		List<Author> authors = new ArrayList<Author>();
		for (Author author : book.getAuthors()) {
			Author foundauthor = authorService.getAuthorById(author.getId());
			if(foundauthor == null) {
				return ResponseEntity.notFound().build();
				}
			authors.add(foundauthor);
		}
		book.setAuthors(authors);
		List<Category> categories = new ArrayList<Category>();
		for (Category category : book.getCategories()) {
			Category foundcategory = categoryService.getCategoryById(category.getId());
			if(foundcategory == null) {
				return ResponseEntity.notFound().build();
				}
			categories.add(foundcategory);
		}
		book.setCategories(categories);
		List<Publisher> publishers = new ArrayList<Publisher>();
		for (Publisher publisher : book.getPublishers()) {
			Publisher foundpublisher = publisherService.getPublisherById(publisher.getId());
			if(foundpublisher == null) {
				return ResponseEntity.notFound().build();
				}
			publishers.add(foundpublisher);
		}
		book.setCategories(categories);
		book.setId(id);//Ensure the ID is set correctly
		bookService.saveOrUpdateBook(book);
		return ResponseEntity.ok(book);
	}
	@PostMapping
	public ResponseEntity<Book> saveBook(@RequestBody Book book){
		List<Author> authors = new ArrayList<Author>();
		for (Author author : book.getAuthors()) {
			Author foundauthor = authorService.getAuthorById(author.getId());
			if(foundauthor == null) {
				return ResponseEntity.notFound().build();
				}
			authors.add(foundauthor);
		}
		book.setAuthors(authors);
		List<Category> categories = new ArrayList<Category>();
		for (Category category : book.getCategories()) {
			Category foundcategory = categoryService.getCategoryById(category.getId());
			if(foundcategory == null) {
				return ResponseEntity.notFound().build();
				}
			categories.add(foundcategory);
		}
		book.setCategories(categories);
		List<Publisher> publishers = new ArrayList<Publisher>();
		for (Publisher publisher : book.getPublishers()) {
			Publisher foundpublisher = publisherService.getPublisherById(publisher.getId());
			if(foundpublisher == null) {
				return ResponseEntity.notFound().build();
				}
			publishers.add(foundpublisher);
		}
		book.setCategories(categories);
		Book createBook = bookService.saveOrUpdateBook(book);
		return ResponseEntity.status(HttpStatus.CREATED).body(createBook);
	}
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteBook(@PathVariable int id){
		bookService.deleteBookById(id);
		return ResponseEntity.noContent().build();
	}
}
