package com.example.soc_lms.repo;

import org.springframework.data.jpa.repository.*;

import com.example.soc_lms.entity.Author;

public interface AuthorRepo extends JpaRepository<Author,Integer> {

}
