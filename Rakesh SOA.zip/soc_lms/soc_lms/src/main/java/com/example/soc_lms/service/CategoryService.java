package com.example.soc_lms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.soc_lms.entity.Category;
import com.example.soc_lms.repo.CategoryRepo;


@Service
public class CategoryService {
	
	@Autowired
	private CategoryRepo categoryRepo;
	
	public List<Category> getAllCategories(){
		return categoryRepo.findAll();
	}
	public Category getCategoryById(int id) {
		return categoryRepo.findById(id)
				.orElseThrow(() -> new RuntimeException("Given Id is Incorrect"));
	}
	public Category saveOrUpdateCategory(Category category) {
		return categoryRepo.save(category);
	}
	public void deleteCategoryById(int id) {
	    categoryRepo.findById(id)
	    .orElseThrow(() -> new RuntimeException("Given Id is Incorrect"));
		categoryRepo.deleteById(id);
	}

}
