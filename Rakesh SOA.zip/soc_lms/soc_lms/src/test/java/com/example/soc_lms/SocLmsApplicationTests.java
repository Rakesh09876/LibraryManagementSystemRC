package com.example.soc_lms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocLmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
